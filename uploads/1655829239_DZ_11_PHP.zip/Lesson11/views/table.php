<form action="">

</form>

<table>
    <thead>
        <tr>
            <th>name</th>
            <th>operation</th>
        </tr>
    </thead>
    <tbody>
    <tr>
        <td><a href="?current_dir=uploads">..</a></td>
    </tr>
        <tr>

            <td><a href="?current_dir=uploads/Folder">Folder</a></td>
            <td><a href="">Delete</a></td>
        </tr>
    </tbody>
</table>